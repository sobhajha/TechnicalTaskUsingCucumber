/**
 * This package contains utility classes for Selenium tests.
 * These classes should contain generally useful functionality to be used from multiple classes.
 */
@javax.xml.bind.annotation.XmlSchema(namespace = "http://docs.oasis-open.org/ws-rx/wsrm/200602")
package com.burning.glass.selenium.util;

