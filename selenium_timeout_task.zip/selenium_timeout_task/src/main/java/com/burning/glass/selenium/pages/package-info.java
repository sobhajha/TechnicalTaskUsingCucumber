/**
 * This package contains classes for PageObject pattern.
 */
@javax.xml.bind.annotation.XmlSchema(namespace = "http://docs.oasis-open.org/ws-rx/wsrm/200602")
package com.burning.glass.selenium.pages;

