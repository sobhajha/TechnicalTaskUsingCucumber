/**
 * Package for image manipulation and comparison.
 */
package com.prisms.selenium.util.image;
